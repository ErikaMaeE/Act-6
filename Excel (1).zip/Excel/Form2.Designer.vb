﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.G6button = New System.Windows.Forms.Button()
        Me.G4button = New System.Windows.Forms.Button()
        Me.G2button = New System.Windows.Forms.Button()
        Me.G5button = New System.Windows.Forms.Button()
        Me.G3button = New System.Windows.Forms.Button()
        Me.G1button = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(716, 327)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(86, 23)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "Grade 6"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(453, 327)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(86, 23)
        Me.Label6.TabIndex = 38
        Me.Label6.Text = "Grade 5"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(173, 327)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(86, 23)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "Grade 4"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(716, 137)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 23)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "Grade 3"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(453, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 23)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Grade 2"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(173, 137)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 23)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Grade 1"
        '
        'G6button
        '
        Me.G6button.BackgroundImage = CType(resources.GetObject("G6button.BackgroundImage"), System.Drawing.Image)
        Me.G6button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.G6button.Location = New System.Drawing.Point(684, 353)
        Me.G6button.Name = "G6button"
        Me.G6button.Size = New System.Drawing.Size(147, 113)
        Me.G6button.TabIndex = 33
        Me.G6button.UseVisualStyleBackColor = True
        '
        'G4button
        '
        Me.G4button.BackgroundImage = CType(resources.GetObject("G4button.BackgroundImage"), System.Drawing.Image)
        Me.G4button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.G4button.Location = New System.Drawing.Point(142, 353)
        Me.G4button.Name = "G4button"
        Me.G4button.Size = New System.Drawing.Size(147, 113)
        Me.G4button.TabIndex = 32
        Me.G4button.UseVisualStyleBackColor = True
        '
        'G2button
        '
        Me.G2button.BackgroundImage = CType(resources.GetObject("G2button.BackgroundImage"), System.Drawing.Image)
        Me.G2button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.G2button.Location = New System.Drawing.Point(420, 163)
        Me.G2button.Name = "G2button"
        Me.G2button.Size = New System.Drawing.Size(147, 113)
        Me.G2button.TabIndex = 31
        Me.G2button.UseVisualStyleBackColor = True
        '
        'G5button
        '
        Me.G5button.BackgroundImage = CType(resources.GetObject("G5button.BackgroundImage"), System.Drawing.Image)
        Me.G5button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.G5button.Location = New System.Drawing.Point(420, 353)
        Me.G5button.Name = "G5button"
        Me.G5button.Size = New System.Drawing.Size(147, 113)
        Me.G5button.TabIndex = 30
        Me.G5button.UseVisualStyleBackColor = True
        '
        'G3button
        '
        Me.G3button.BackgroundImage = CType(resources.GetObject("G3button.BackgroundImage"), System.Drawing.Image)
        Me.G3button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.G3button.Location = New System.Drawing.Point(684, 163)
        Me.G3button.Name = "G3button"
        Me.G3button.Size = New System.Drawing.Size(147, 113)
        Me.G3button.TabIndex = 29
        Me.G3button.UseVisualStyleBackColor = True
        '
        'G1button
        '
        Me.G1button.BackgroundImage = CType(resources.GetObject("G1button.BackgroundImage"), System.Drawing.Image)
        Me.G1button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.G1button.Location = New System.Drawing.Point(142, 163)
        Me.G1button.Name = "G1button"
        Me.G1button.Size = New System.Drawing.Size(147, 113)
        Me.G1button.TabIndex = 28
        Me.G1button.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(385, 62)
        Me.Label1.Margin = New System.Windows.Forms.Padding(5, 0, 5, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(218, 36)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "STUDENT FORM"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(973, 528)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.G6button)
        Me.Controls.Add(Me.G4button)
        Me.Controls.Add(Me.G2button)
        Me.Controls.Add(Me.G5button)
        Me.Controls.Add(Me.G3button)
        Me.Controls.Add(Me.G1button)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents G6button As Button
    Friend WithEvents G4button As Button
    Friend WithEvents G2button As Button
    Friend WithEvents G5button As Button
    Friend WithEvents G3button As Button
    Friend WithEvents G1button As Button
    Friend WithEvents Label1 As Label
End Class
