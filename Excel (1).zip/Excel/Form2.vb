﻿Public Class Form2
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub G1button_Click(sender As Object, e As EventArgs) Handles G1button.Click
        Form9.Show()
    End Sub

    Private Sub G3button_Click(sender As Object, e As EventArgs) Handles G3button.Click
        Form3.Show()
    End Sub

    Private Sub G2button_Click(sender As Object, e As EventArgs) Handles G2button.Click
        Form8.Show()
    End Sub

    Private Sub G4button_Click(sender As Object, e As EventArgs) Handles G4button.Click
        Form4.Show()
    End Sub

    Private Sub G6button_Click(sender As Object, e As EventArgs) Handles G6button.Click
        Form6.Show()
    End Sub

    Private Sub G5button_Click(sender As Object, e As EventArgs) Handles G5button.Click
        Form5.Show()
    End Sub
End Class